﻿using ABCRETAIL.Models;
using ABCRETAIL.Services;
using ABCRETAIL.Services.Storage;

namespace ABCRETAIL
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddControllersWithViews();

            var storageConnectionString = builder.Configuration.GetConnectionString("StorageConnectionString")
                ?? throw new InvalidOperationException("Storage connection string is missing in appsettings.json");

            // ✅ Register Table Storage Services
            builder.Services.AddSingleton<TableStorageService<CustomerEntity>>(
                _ => new TableStorageService<CustomerEntity>(storageConnectionString, "Customers"));
            builder.Services.AddSingleton<TableStorageService<ProductEntity>>(
                _ => new TableStorageService<ProductEntity>(storageConnectionString, "Products"));
            builder.Services.AddSingleton<TableStorageService<OrderEntity>>(
                _ => new TableStorageService<OrderEntity>(storageConnectionString, "Orders"));

            // ✅ Register Domain Services
            builder.Services.AddScoped<CustomerService>(sp =>
                new CustomerService(sp.GetRequiredService<TableStorageService<CustomerEntity>>()));
            builder.Services.AddScoped<ProductService>(sp =>
                new ProductService(sp.GetRequiredService<TableStorageService<ProductEntity>>()));
            builder.Services.AddScoped<OrderService>(sp =>
                new OrderService(sp.GetRequiredService<TableStorageService<OrderEntity>>()));

            // ✅ Register Blob Storage Service (for product images)
            builder.Services.AddSingleton<BlobStorageService>(sp =>
            {
                string containerName = "product-images";
                return new BlobStorageService(storageConnectionString, containerName);
            });

            // ✅ Register Queue Storage Service (for audit logs)
            builder.Services.AddSingleton<QueueStorageService>(sp =>
            {
                string queueName = "auditlog"; // 📝 Ensure this queue exists in Azure
                return new QueueStorageService(storageConnectionString, queueName);
            });

            // ✅ Register File Share Storage Service (for CSV exports)
            builder.Services.AddSingleton<FileShareStorageService>(sp =>
            {
                string shareName = "audit-exports"; // 📝 Ensure this file share exists in Azure
                return new FileShareStorageService(storageConnectionString, shareName);
            });

            var app = builder.Build();

            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseRouting();
            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }
    }
}

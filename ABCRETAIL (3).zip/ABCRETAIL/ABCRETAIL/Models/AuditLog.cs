﻿using System;

namespace ABCRETAIL.Models
{
    // Lightweight model for presenting queue messages in UI
    public class AuditLog
    {
        public string MessageId { get; set; } = string.Empty;
        public DateTimeOffset? QueueInsertionTime { get; set; }
        public DateTime? EventTimestamp { get; set; }
        public string Action { get; set; } = string.Empty;
        public string Entity { get; set; } = string.Empty;
        public string? EntityId { get; set; }
    }
}

﻿using ABCRETAIL.Models;
using ABCRETAIL.Services.Storage;

namespace ABCRETAIL.Services
{
    public class CustomerService
    {
        private readonly TableStorageService<CustomerEntity> _table;
        public CustomerService(TableStorageService<CustomerEntity> table) => _table = table;

        public Task<List<CustomerEntity>> GetAllAsync() => _table.GetAllAsync();

        public Task<CustomerEntity?> GetByIdAsync(string id) => _table.TryGetAsync("CUSTOMER", id);

        public async Task AddAsync(CustomerEntity entity)
        {
            if (string.IsNullOrWhiteSpace(entity.RowKey)) entity.RowKey = Guid.NewGuid().ToString();
            entity.PartitionKey = "CUSTOMER";
            await _table.AddAsync(entity);
        }

        public async Task UpdateAsync(CustomerEntity entity)
        {
            entity.PartitionKey = "CUSTOMER";
            if (string.IsNullOrWhiteSpace(entity.RowKey)) throw new ArgumentException("Customer RowKey is required for update.");
            await _table.UpdateAsync(entity);
        }

        public Task DeleteAsync(string id) => _table.DeleteAsync("CUSTOMER", id);
    }
}

﻿using Azure;
using Azure.Data.Tables;

namespace ABCRETAIL.Services.Storage
{
    // Generic wrapper for Azure Table Storage operations
    public class TableStorageService<T> where T : class, ITableEntity, new()
    {
        private readonly TableClient _tableClient;

        public TableStorageService(string connectionString, string tableName)
        {
            _tableClient = new TableClient(connectionString, tableName);
            _tableClient.CreateIfNotExists();
        }

        public async Task<List<T>> GetAllAsync()
        {
            var results = new List<T>();
            await foreach (var e in _tableClient.QueryAsync<T>())
                results.Add(e);
            return results;
        }

        public async Task<T?> TryGetAsync(string partitionKey, string rowKey)
        {
            if (string.IsNullOrWhiteSpace(partitionKey)) throw new ArgumentException(nameof(partitionKey));
            if (string.IsNullOrWhiteSpace(rowKey)) throw new ArgumentException(nameof(rowKey));

            try
            {
                var resp = await _tableClient.GetEntityAsync<T>(partitionKey, rowKey);
                return resp.Value;
            }
            catch (RequestFailedException ex) when (ex.Status == 404)
            {
                return null;
            }
        }

        public async Task AddAsync(T entity)
        {
            EnsureKeysForWrite(entity);
            await _tableClient.AddEntityAsync(entity);
        }

        public async Task UpdateAsync(T entity)
        {
            EnsureKeysForWrite(entity);
            // Use ETag.All to avoid requiring callers to manage ETags
            await _tableClient.UpdateEntityAsync(entity, ETag.All, TableUpdateMode.Replace);
        }

        public async Task DeleteAsync(string partitionKey, string rowKey)
        {
            if (string.IsNullOrWhiteSpace(partitionKey)) throw new ArgumentException(nameof(partitionKey));
            if (string.IsNullOrWhiteSpace(rowKey)) throw new ArgumentException(nameof(rowKey));
            await _tableClient.DeleteEntityAsync(partitionKey, rowKey);
        }

        private static void EnsureKeysForWrite(T entity)
        {
            if (entity == null) throw new ArgumentNullException(nameof(entity));
            if (string.IsNullOrWhiteSpace(entity.PartitionKey)) throw new ArgumentException("PartitionKey must be provided on entity.");
            if (string.IsNullOrWhiteSpace(entity.RowKey)) throw new ArgumentException("RowKey must be provided on entity.");
        }
    }
}

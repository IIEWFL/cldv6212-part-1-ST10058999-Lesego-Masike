﻿using ABCRETAIL.Models;
using ABCRETAIL.Services;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Text.Json;

namespace ABCRETAIL.Controllers
{
    public class AuditLogController : Controller
    {
        private readonly QueueStorageService _queueStorageService;
        private readonly FileShareStorageService _fileShareStorageService;

        public AuditLogController(QueueStorageService queueStorageService, FileShareStorageService fileShareStorageService)
        {
            _queueStorageService = queueStorageService;
            _fileShareStorageService = fileShareStorageService;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                var messages = await _queueStorageService.GetMessagesAsync();
                var logs = messages.Select(m =>
                {
                    var decoded = Encoding.UTF8.GetString(Convert.FromBase64String(m.MessageText));
                    using var doc = JsonDocument.Parse(decoded);
                    var root = doc.RootElement;

                    var entity = "Entity";
                    if (root.TryGetProperty("Details", out var d) && d.ValueKind == JsonValueKind.Object)
                    {
                        if (d.TryGetProperty("StudentNumber", out _)) entity = "Student";
                        else if (d.TryGetProperty("Name", out _)) entity = "Customer/Product/Order";
                    }

                    return new AuditLog
                    {
                        MessageId = m.MessageId,
                        QueueInsertionTime = m.InsertedOn,
                        EventTimestamp = root.TryGetProperty("Timestamp", out var ts) ? ts.GetDateTime() : null,
                        Action = root.TryGetProperty("Action", out var a) ? a.GetString() ?? string.Empty : string.Empty,
                        Entity = entity,
                        EntityId = root.TryGetProperty("Details", out var dd) && dd.TryGetProperty("RowKey", out var rk) ? rk.GetString() : null
                    };
                }).ToList();

                return View(logs);
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Failed to load audit logs: {ex.Message}";
                return View(Enumerable.Empty<AuditLog>());
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Export()
        {
            try
            {
                var bytes = await BuildCsvAsync();
                var filename = $"AuditLog_{DateTime.UtcNow:yyyyMMddHHmmss}.csv";

                using (var uploadStream = new MemoryStream(bytes))
                {
                    await _fileShareStorageService.UploadFileAsync(filename, uploadStream);
                }

                return File(bytes, "text/csv", filename);
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"CSV export failed: {ex.Message}";
                return RedirectToAction(nameof(Index));
            }
        }

        [HttpGet]
        public async Task<IActionResult> ViewCsv()
        {
            try
            {
                var bytes = await BuildCsvAsync();
                Response.Headers["Content-Disposition"] = "inline; filename=AuditLog.csv";
                return File(bytes, "text/csv");
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"CSV view failed: {ex.Message}";
                return RedirectToAction(nameof(Index));
            }
        }

        private async Task<byte[]> BuildCsvAsync()
        {
            var messages = await _queueStorageService.GetMessagesAsync();

            using var ms = new MemoryStream();
            using var writer = new StreamWriter(ms, Encoding.UTF8, 1024, leaveOpen: true);

            await writer.WriteLineAsync("MessageId,QueueInsertionTime,EventTimestamp,Action,Entity,EntityId");

            foreach (var m in messages)
            {
                var decoded = Encoding.UTF8.GetString(Convert.FromBase64String(m.MessageText));
                using var doc = JsonDocument.Parse(decoded);
                var root = doc.RootElement;

                var eventTimestamp = root.TryGetProperty("Timestamp", out var ts)
                    ? ts.GetDateTime().ToString("yyyy/MM/dd HH:mm:ss")
                    : "";

                var action = root.TryGetProperty("Action", out var a) ? a.GetString() ?? "" : "";

                var entity = "Entity";
                string? entityId = null;

                if (root.TryGetProperty("Details", out var d) && d.ValueKind == JsonValueKind.Object)
                {
                    if (d.TryGetProperty("StudentNumber", out _)) entity = "Student";
                    else if (d.TryGetProperty("Name", out _)) entity = "Customer/Product/Order";

                    if (d.TryGetProperty("RowKey", out var rk)) entityId = rk.GetString();
                }

                await writer.WriteLineAsync(
                    $"\"{m.MessageId}\",\"{m.InsertedOn:yyyy/MM/dd HH:mm:ss}\",\"{eventTimestamp}\",\"{action}\",\"{entity}\",\"{entityId}\"");
            }

            await writer.FlushAsync();
            ms.Position = 0;
            return ms.ToArray();
        }
    }
}
